#!bin/bash

virtualenv -p /usr/bin/python2.7 django_site
cd django_site
. $PWD/bin/activate

pip install -e git+https://github.com/django-leonardo/django-leonardo#egg=django-leonardo
pip install -r $PWD/src/django-leonardo/requirements.txt
django-admin startproject --template=https://github.com/django-leonardo/site-template/archive/master.zip website

export PYTHONPATH=$PWD/website

wget -O - https://raw.githubusercontent.com/dresl/python_web_grayscale_bootstrap_theme/master/bash_scripts/get_scripts.sh | sh
