#!bin/bash

mkdir /srv/leonardo/
mkdir /srv/leonardo/sites
