#!bin/bash

. bin/activate

pip install -e git+https://github.com/django-leonardo/django-leonardo@#egg=django_leonardo
pip install -e git+https://github.com/dresl/leonardo-cookie-law.git@#egg=leonardo_cookie_law
pip install -e git+https://github.com/leonardo-modules/leonardo-geo@#egg=leonardo_geo
pip install -e git+https://github.com/leonardo-modules/leonardo-iconlink.git@#egg=leonardo_iconlink
pip install -e git+https://github.com/leonardo-modules/leonardo-module-blog@#egg=leonardo_module_blog
pip install -e git+https://github.com/leonardo-modules/leonardo-module-forms@#egg=leonardo_module_forms
pip install -e git+https://github.com/dresl/leonardo-module-links.git@#egg=leonardo_module_links
pip install -e git+https://github.com/dresl/leonardo-multicalc.git@#egg=leonardo_multicalc
pip install -e git+https://github.com/dresl/leonardo-polls.git@#egg=leonardo_polls
pip install -e git+https://github.com/leonardo-modules/leonardo-scrolltop@#egg=leonardo_scrolltop
pip install -e git+https://github.com/leonardo-modules/leonardo-theme-grayscale.git@#egg=leonardo_theme_grayscale
pip install -e git+https://github.com/dresl/leonardo-theme-portfolioitem.git@#egg=leonardo_theme_portfolioitem
